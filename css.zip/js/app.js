/* ============================================
   SetLogix App Entry Point — app.js
   ============================================ */

(function initApp() {
  'use strict';

  // Initialize store and i18n
  Store.init();
  I18n.init();

  // Register screens
  Router.register('dashboard', DashboardScreen);
  Router.register('workout', WorkoutScreen);
  Router.register('program', ProgramScreen);
  Router.register('progress', ProgressScreen);
  Router.register('exercises', ExercisesScreen);
  Router.register('calculators', CalculatorsScreen);
  Router.register('more', MoreScreen);

  // Render navbar
  Navbar.render();

  // Initialize router
  Router.init();

  // Register service worker
  if ('serviceWorker' in navigator) {
    window.addEventListener('load', () => {
      navigator.serviceWorker.register('sw.js')
        .then(reg => console.log('[SW] Registered:', reg.scope))
        .catch(err => console.warn('[SW] Registration failed:', err));
    });
  }

  console.log('%c SetLogix v1.0 ', 'background: #e86a33; color: white; font-size: 14px; font-weight: bold; border-radius: 4px; padding: 4px 8px;');
})();
