/* ============================================
   SetLogix Dashboard Screen — dashboard.js
   ============================================ */

const DashboardScreen = (() => {

  function getGreeting() {
    const hour = new Date().getHours();
    if (hour < 12) return I18n.t('greeting_morning');
    if (hour < 17) return I18n.t('greeting_afternoon');
    return I18n.t('greeting_evening');
  }

  function getWeekDayBars() {
    const days = [I18n.t('mon'), I18n.t('tue'), I18n.t('wed'), I18n.t('thu'), I18n.t('fri'), I18n.t('sat'), I18n.t('sun')];
    const now = new Date();
    const dayOfWeek = (now.getDay() + 6) % 7;
    const thisWeek = Store.getThisWeekWorkouts();
    const workedDays = new Set();
    thisWeek.forEach(w => {
      const d = new Date(w.completedAt);
      workedDays.add((d.getDay() + 6) % 7);
    });
    return days.map((d, i) => {
      const active = workedDays.has(i);
      return `<div class="week-bar ${active ? 'active' : ''} ${i === dayOfWeek ? 'today' : ''}">
        <div class="week-bar-fill"></div>
        <span class="week-bar-label">${d}</span>
      </div>`;
    }).join('');
  }

  function render() {
    const user = Store.get('user');
    const activeSession = Store.get('activeSession');
    const weekWorkouts = Store.getThisWeekWorkouts();
    const history = Store.get('workoutHistory') || [];
    
    const totalWorkouts = history.length;
    const motives = ['motive_1', 'motive_2', 'motive_3', 'motive_4'];
    const motiveKey = motives[totalWorkouts % 4];
    const motiveStr = I18n.t(motiveKey);
    const lastWorkout = history[0];
    const programs = Store.get('programs') || [];
    const todayProgram = programs[0];
    
    let nextDayIdx = 0;
    if (history.length > 0 && todayProgram && todayProgram.days) {
      const lastW = history[0];
      const lastIdx = todayProgram.days.findIndex(d => d.id === lastW.programDayId);
      if (lastIdx !== -1) {
        nextDayIdx = (lastIdx + 1) % todayProgram.days.length;
      } else {
        const fallbackIdx = todayProgram.days.findIndex(d => d.name.includes(lastW.name) || lastW.name.includes(d.name));
        if (fallbackIdx !== -1) nextDayIdx = (fallbackIdx + 1) % todayProgram.days.length;
      }
    }
    const todayDay = todayProgram?.days[nextDayIdx];
    const weekCount = weekWorkouts.length;
    const weekGoal = 5;
    const pct = Math.min(100, Math.round((weekCount / weekGoal) * 100));
    const circ = 2 * Math.PI * 54;
    const dash = circ - (pct / 100) * circ;
    const btnLabel = activeSession ? I18n.t('resume_session') : I18n.t('start_session');
    const btnAction = activeSession ? 'DashboardScreen.resumeWorkout()' : 'DashboardScreen.startWorkout()';

    let lastWorkoutHTML = '';
    if (lastWorkout) {
      const exList = lastWorkout.exercises.slice(0, 3).map(ex => {
        const info = Store.getExerciseInfo(ex.exerciseId);
        const best = ex.sets.reduce((a, b) => b.weight > a.weight ? b : a, ex.sets[0]);
        return `<div class="last-workout-exercise">
          <span class="text-secondary">${info.name}</span>
          <span class="fw-500">${best.weight} kg x ${best.reps}</span>
        </div>`;
      }).join('');

      lastWorkoutHTML = `<div class="dash-section">
        <div class="section-header">
          <span class="section-title">${I18n.t('last_workout')}</span>
          <button class="btn-ghost" onclick="Router.navigate('#progress')">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="9 18 15 12 9 6"/></svg>
          </button>
        </div>
        <div class="card last-workout-card">
          <div class="flex-between" style="margin-bottom:8px">
            <div>
              <h4 class="fw-600">${lastWorkout.name}</h4>
              <p class="fs-12 text-secondary">${Render.formatDate(lastWorkout.completedAt)}</p>
            </div>
          </div>
          <div class="last-workout-exercises">${exList}</div>
        </div>
      </div>`;
    }

    return `<div class="screen dashboard-screen" id="dashboard">
      <div class="dash-header">
        <button class="btn-icon btn-ghost" onclick="Router.navigate('#more')"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg></button>
        <div class="dash-logo">SET<span class="text-accent">LOGIX</span></div>
        <button class="btn-icon btn-ghost"><svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 01-3.46 0"/></svg></button>
      </div>
      <div class="dash-greeting">
        <p class="dash-greeting-sub">${getGreeting()}</p>
        <h1 class="dash-greeting-name">${user.name}</h1>
        <div class="dash-streak" style="display:flex; flex-direction:column; align-items:flex-start; gap:2px; margin-top:8px;">
          <div style="display:flex; align-items:center; gap:6px;">
            <span class="streak-fire">🔥</span>
            <span>${totalWorkouts} ${I18n.t('workouts_completed')}</span>
          </div>
          <span style="font-size:12px; color:var(--text-secondary); margin-left:26px;">${motiveStr}</span>
        </div>
      </div>
      <div class="dash-section">
        <div class="section-header"><span class="section-title">${I18n.t('todays_workout')}</span></div>
        <div class="today-card">
          <div class="today-card-content">
            <div>
              <h3 class="today-card-title">${todayDay?.name?.replace(/Day \d+ – /, '') || 'Push Day'}</h3>
              <p class="today-card-subtitle">${todayDay?.exercises.length || 6} ${I18n.t('exercises')}</p>
            </div>
            <div class="today-card-illustration">
              <svg width="60" height="60" viewBox="0 0 80 80" fill="none">
                <circle cx="40" cy="15" r="8" fill="#e86a33" opacity="0.8"/>
                <rect x="35" y="23" width="10" height="22" rx="3" fill="#e86a33" opacity="0.7"/>
                <rect x="20" y="28" width="40" height="4" rx="2" fill="#e86a33" opacity="0.6"/>
                <rect x="14" y="26" width="8" height="8" rx="2" fill="#e86a33" opacity="0.5"/>
                <rect x="58" y="26" width="8" height="8" rx="2" fill="#e86a33" opacity="0.5"/>
                <rect x="32" y="45" width="6" height="20" rx="2" fill="#e86a33" opacity="0.6"/>
                <rect x="42" y="45" width="6" height="20" rx="2" fill="#e86a33" opacity="0.6"/>
              </svg>
            </div>
          </div>
          <button class="btn btn-primary btn-block btn-lg start-session-btn" onclick="${btnAction}">
            <span>${btnLabel}</span>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><polygon points="5 3 19 12 5 21 5 3"/></svg>
          </button>
        </div>
      </div>
      <div class="dash-section">
        <div class="section-header"><span class="section-title">${I18n.t('weekly_progress')}</span></div>
        <div class="weekly-card">
          <div class="weekly-ring-container">
            <svg class="weekly-ring" viewBox="0 0 120 120">
              <circle cx="60" cy="60" r="54" stroke="var(--border)" stroke-width="8" fill="none"/>
              <circle cx="60" cy="60" r="54" stroke="var(--accent)" stroke-width="8" fill="none"
                stroke-dasharray="${circ}" stroke-dashoffset="${dash}" stroke-linecap="round" transform="rotate(-90 60 60)"/>
            </svg>
            <div class="weekly-ring-text">
              <span class="weekly-ring-count">${weekCount}</span>
              <span class="weekly-ring-label">/${weekGoal}</span>
            </div>
          </div>
          <div class="weekly-info">
            <p class="weekly-info-title">${I18n.t('workouts_this_week').replace('\\n', '<br>')}</p>
            <div class="weekly-bars">${getWeekDayBars()}</div>
          </div>
        </div>
      </div>
      ${lastWorkoutHTML}
    </div>`;
  }

  function startWorkout() {
    const programs = Store.get('programs') || [];
    const prog = programs[0];
    if (!prog) { Toast.show('No program found!', 'warning'); return; }
    
    const history = Store.get('workoutHistory') || [];
    let nextDayIdx = 0;
    if (history.length > 0 && prog.days) {
      const lastW = history[0];
      const lastIdx = prog.days.findIndex(d => d.id === lastW.programDayId);
      if (lastIdx !== -1) {
        nextDayIdx = (lastIdx + 1) % prog.days.length;
      } else {
        const fallbackIdx = prog.days.findIndex(d => d.name.includes(lastW.name) || lastW.name.includes(d.name));
        if (fallbackIdx !== -1) nextDayIdx = (fallbackIdx + 1) % prog.days.length;
      }
    }
    const day = prog.days[nextDayIdx];
    
    const ok = Store.startWorkout(day.id, day.name.replace(/Day \d+ – /, '').replace(/Yeni Gün \d+/, 'Workout'), day.exercises);
    if (ok) { Toast.show('Let\'s go! 💪', 'success'); }
    Router.navigate('#workout');
  }

  function resumeWorkout() { Router.navigate('#workout'); }
  function afterRender() {}
  function cleanup() {}

  return { render, afterRender, cleanup, startWorkout, resumeWorkout };
})();
