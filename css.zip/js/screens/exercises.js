/* ============================================
   SetLogix Exercises Screen — exercises.js
   ============================================ */

const ExercisesScreen = (() => {
  let searchQuery = '';
  let activeFilter = 'All';

  function render() {
    const favorites = Store.get('favorites') || [];
    let filtered = EXERCISE_DB;

    if (activeFilter !== 'All') {
      filtered = filtered.filter(e => e.muscle === activeFilter);
    }
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      filtered = filtered.filter(e => e.name.toLowerCase().includes(q) || e.type.toLowerCase().includes(q));
    }

    const chips = MUSCLE_GROUPS.map(g =>
      `<button class="chip ${activeFilter === g ? 'active' : ''}" onclick="ExercisesScreen.setFilter('${g}')">${g}</button>`
    ).join('');

    const list = filtered.map(ex => {
      const isFav = favorites.includes(ex.id);
      return `<div class="list-item" onclick="ExercisesScreen.viewExercise('${ex.id}')">
        <div class="list-item-icon">${ex.icon}</div>
        <div class="list-item-content">
          <div class="list-item-title">${ex.name}</div>
          <div class="list-item-subtitle">${ex.type}</div>
        </div>
        <button class="btn-icon btn-ghost fav-btn ${isFav ? 'fav-active' : ''}" onclick="event.stopPropagation(); ExercisesScreen.toggleFav('${ex.id}')">
          ${isFav ? '★' : '☆'}
        </button>
        <span class="list-item-arrow">›</span>
      </div>`;
    }).join('');

    return `<div class="screen exercises-screen" id="exercises-screen">
      <div class="screen-header">
        <h1>${I18n.t('exercises')}</h1>
      </div>
      <div class="search-bar-container">
        <div class="search-bar">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--text-tertiary)" stroke-width="2"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg>
          <input type="text" class="search-input" placeholder="${I18n.t('search')}..." value="${searchQuery}" 
            oninput="ExercisesScreen.search(this.value)" id="exercise-search">
        </div>
        <button class="btn-icon btn-ghost">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3"/></svg>
        </button>
      </div>
      <div class="chip-bar" style="padding:0 16px 12px">${chips}</div>
      <div class="card" style="margin:0 16px;padding:0">${list || '<p class="text-secondary" style="padding:16px">No exercises found</p>'}</div>
      <button class="fab" onclick="ExercisesScreen.addCustom()">+</button>
    </div>`;
  }

  function search(q) {
    searchQuery = q;
    refreshScreen();
  }

  function setFilter(f) {
    activeFilter = f;
    refreshScreen();
  }

  function toggleFav(id) {
    Store.toggleFavorite(id);
    refreshScreen();
  }

  function viewExercise(id) {
    const info = Store.getExerciseInfo(id);
    const pr = Store.getPersonalRecord(id);
    const prStr = pr ? `${pr.weight} kg x ${pr.reps}` : 'No data yet';
    Modal.open(`<div class="modal-dialog">
      <div class="flex gap-md" style="margin-bottom:12px">
        <div class="list-item-icon" style="width:48px;height:48px;font-size:24px">${info.icon}</div>
        <div>
          <h3>${info.name}</h3>
          <p class="text-secondary fs-13">${info.type} · ${info.muscle}</p>
        </div>
      </div>
      <div class="divider"></div>
      <div class="flex-between" style="padding:8px 0">
        <span class="text-secondary">Personal Record</span>
        <span class="fw-600">${prStr}</span>
      </div>
      <button class="btn btn-primary btn-block" style="margin-top:12px" onclick="Modal.close()">Close</button>
    </div>`);
  }

  function addCustom() {
    Toast.show('Custom exercise creator coming soon!', 'info');
  }

  function refreshScreen() {
    const container = document.getElementById('screen-container');
    if (container && Router.getCurrentScreen() === 'exercises') {
      container.innerHTML = render();
    }
  }

  function afterRender() {}
  function cleanup() { searchQuery = ''; activeFilter = 'All'; }

  return { render, afterRender, cleanup, search, setFilter, toggleFav, viewExercise, addCustom };
})();
