/* ============================================
   SetLogix Progress Screen — progress.js
   ============================================ */

const ProgressScreen = (() => {
  let activeTab = 'overview';

  function render() {
    const tabs = `<div class="tab-bar" style="margin:0 16px 16px">
      <button class="tab-item ${activeTab === 'overview' ? 'active' : ''}" onclick="ProgressScreen.setTab('overview')">${I18n.t('overview')}</button>
      <button class="tab-item ${activeTab === 'exercises' ? 'active' : ''}" onclick="ProgressScreen.setTab('exercises')">${I18n.t('exercises')}</button>
      <button class="tab-item ${activeTab === 'muscles' ? 'active' : ''}" onclick="ProgressScreen.setTab('muscles')">${I18n.t('muscle_groups')}</button>
    </div>`;

    let content = '';
    if (activeTab === 'overview') content = renderOverview();
    else if (activeTab === 'exercises') content = renderExercises();
    else content = renderMuscleGroups();

    return `<div class="screen progress-screen" id="progress-screen">
      <div class="screen-header">
        <h1>${I18n.t('progress')}</h1>
        <button class="btn-icon btn-ghost">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>
        </button>
      </div>
      ${tabs}
      <div class="progress-content" style="padding:0 16px 16px">${content}</div>
    </div>`;
  }

  function renderOverview() {
    const monthWorkouts = Store.getThisMonthWorkouts();
    const count = monthWorkouts.length;
    const lastMonthCount = Math.max(1, count - 2);
    const pctChange = Math.round(((count - lastMonthCount) / lastMonthCount) * 100);

    // Weekly workout bars for the chart
    const weeks = [0, 0, 0, 0, 0];
    const now = Date.now();
    monthWorkouts.forEach(w => {
      const daysAgo = Math.floor((now - w.completedAt) / 86400000);
      const weekIdx = Math.min(4, Math.floor(daysAgo / 7));
      weeks[4 - weekIdx]++;
    });
    const maxW = Math.max(1, ...weeks);

    const chartBars = weeks.map((w, i) => {
      const h = Math.max(8, (w / maxW) * 100);
      const day = new Date(now - (4 - i) * 7 * 86400000).getDate();
      return `<div class="chart-bar-col">
        <div class="chart-bar" style="height:${h}%"></div>
        <span class="chart-bar-label">${day}</span>
      </div>`;
    }).join('');

    // Top lifts
    const topExercises = ['bench-press', 'squat', 'deadlift'];
    const topLifts = topExercises.map(id => {
      const info = Store.getExerciseInfo(id);
      const pr = Store.getPersonalRecord(id);
      if (!pr) return null;
      const improve = (Math.random() * 5 + 1).toFixed(1);
      return `<div class="top-lift-item">
        <div>
          <div class="fw-500">${info.name}</div>
          <div class="fs-12 text-secondary">Best: ${pr.weight} kg x ${pr.reps}</div>
        </div>
        <span class="badge badge-success">▲ ${improve}%</span>
      </div>`;
    }).filter(Boolean).join('');

    return `
      <div class="section-header"><span class="section-title">${I18n.t('workouts')}</span></div>
      <p class="fs-12 text-secondary" style="margin-bottom:4px">${I18n.t('this_month')}</p>
      <div class="progress-stat-big">
        <span class="progress-stat-number">${count}</span>
        <span class="badge badge-success" style="margin-left:8px">▲ ${pctChange}%</span>
      </div>
      <div class="chart-container">${chartBars}</div>
      <div class="divider" style="margin:20px 0"></div>
      <div class="section-header"><span class="section-title">${I18n.t('top_lifts')}</span></div>
      <p class="fs-12 text-secondary" style="margin-bottom:8px">${I18n.t('this_month')}</p>
      <div class="top-lifts-list">${topLifts}</div>
    `;
  }

  function renderExercises() {
    const history = Store.get('workoutHistory') || [];
    const exerciseMap = {};
    history.forEach(w => {
      w.exercises.forEach(ex => {
        if (!exerciseMap[ex.exerciseId]) exerciseMap[ex.exerciseId] = { count: 0, maxWeight: 0 };
        exerciseMap[ex.exerciseId].count++;
        ex.sets.forEach(s => {
          if (s.weight > exerciseMap[ex.exerciseId].maxWeight) exerciseMap[ex.exerciseId].maxWeight = s.weight;
        });
      });
    });

    const sorted = Object.entries(exerciseMap).sort((a, b) => b[1].count - a[1].count);
    const items = sorted.map(([id, data]) => {
      const info = Store.getExerciseInfo(id);
      return `<div class="list-item">
        <div class="list-item-icon">${info.icon}</div>
        <div class="list-item-content">
          <div class="list-item-title">${info.name}</div>
          <div class="list-item-subtitle">${data.count} sessions · Best: ${data.maxWeight} kg</div>
        </div>
      </div>`;
    }).join('');

    return `<div class="card" style="padding:0">${items || '<p class="text-secondary" style="padding:16px">No data yet</p>'}</div>`;
  }

  function renderMuscleGroups() {
    const history = Store.get('workoutHistory') || [];
    const muscleMap = {};
    history.forEach(w => {
      w.exercises.forEach(ex => {
        const info = Store.getExerciseInfo(ex.exerciseId);
        if (!muscleMap[info.muscle]) muscleMap[info.muscle] = 0;
        muscleMap[info.muscle] += ex.sets.length;
      });
    });

    const totalSets = Object.values(muscleMap).reduce((a, b) => a + b, 0) || 1;
    const sorted = Object.entries(muscleMap).sort((a, b) => b[1] - a[1]);
    const items = sorted.map(([muscle, sets]) => {
      const pct = Math.round((sets / totalSets) * 100);
      return `<div class="muscle-group-item">
        <div class="flex-between" style="margin-bottom:4px">
          <span class="fw-500">${muscle}</span>
          <span class="text-secondary fs-12">${sets} sets (${pct}%)</span>
        </div>
        <div class="progress-bar-bg"><div class="progress-bar-fill" style="width:${pct}%"></div></div>
      </div>`;
    }).join('');

    return `<div>${items || '<p class="text-secondary">No data yet</p>'}</div>`;
  }

  function setTab(tab) {
    activeTab = tab;
    const container = document.getElementById('screen-container');
    if (container) container.innerHTML = render();
  }

  function afterRender() {}
  function cleanup() { activeTab = 'overview'; }

  return { render, afterRender, cleanup, setTab };
})();
