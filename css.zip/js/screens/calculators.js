/* ============================================
   SetLogix Calculators Screen — calculators.js
   ============================================ */

const CalculatorsScreen = (() => {
  let activeCalc = null;
  let calcValues = {};

  const calculators = [
    { id: '1rm', name: '1RM Calculator', desc: 'Calculate your one rep max', icon: '🏋️' },
    { id: 'strength', name: 'Strength Standards', desc: 'Compare your lifts', icon: '📊' },
    { id: 'plate', name: 'Plate Calculator', desc: 'Plan your next lift', icon: '🔩' },
    { id: 'bodyfat', name: 'Body Fat Calculator', desc: 'Estimate your body fat %', icon: '📏' },
    { id: 'macro', name: 'Macro Calculator', desc: 'Calculate your macros', icon: '🥗' },
  ];

  function render() {
    if (activeCalc) return renderCalculator(activeCalc);
    const list = calculators.map(c =>
      `<div class="list-item" onclick="CalculatorsScreen.openCalc('${c.id}')">
        <div class="list-item-icon">${c.icon}</div>
        <div class="list-item-content">
          <div class="list-item-title">${c.name}</div>
          <div class="list-item-subtitle">${c.desc}</div>
        </div>
        <span class="list-item-arrow">›</span>
      </div>`
    ).join('');

    return `<div class="screen calculators-screen" id="calculators-screen">
      <div class="screen-header"><h1>Calculators</h1></div>
      <div class="card" style="margin:0 16px;padding:0">${list}</div>
    </div>`;
  }

  function renderCalculator(id) {
    let content = '';
    const backBtn = `<button class="btn-icon btn-ghost" onclick="CalculatorsScreen.back()">
      <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
    </button>`;

    if (id === '1rm') {
      const w = calcValues.weight || '';
      const r = calcValues.reps || '';
      let result = '';
      if (w && r && r > 0) {
        const oneRM = (parseFloat(w) * (1 + parseFloat(r) / 30)).toFixed(1);
        result = `<div class="calc-result">
          <p class="calc-result-label">Estimated 1RM</p>
          <p class="calc-result-value">${oneRM} <span class="fs-16">kg</span></p>
          <div class="calc-percentages">
            ${[100,95,90,85,80,75,70,65].map(pct => 
              `<div class="calc-pct-row"><span>${pct}%</span><span class="fw-600">${(oneRM * pct / 100).toFixed(1)} kg</span></div>`
            ).join('')}
          </div>
        </div>`;
      }
      content = `<div class="calc-form">
        <div class="calc-field">
          <label>Weight (kg)</label>
          <input type="number" class="input-field" value="${w}" placeholder="e.g. 100" inputmode="decimal"
            oninput="CalculatorsScreen.setValue('weight',this.value)">
        </div>
        <div class="calc-field">
          <label>Reps</label>
          <input type="number" class="input-field" value="${r}" placeholder="e.g. 5" inputmode="numeric"
            oninput="CalculatorsScreen.setValue('reps',this.value)">
        </div>
        ${result}
      </div>`;
    } else if (id === 'bodyfat') {
      const h = calcValues.height || '';
      const w = calcValues.bfWeight || '';
      const waist = calcValues.waist || '';
      const neck = calcValues.neck || '';
      let result = '';
      if (h && waist && neck) {
        const bf = (495 / (1.0324 - 0.19077 * Math.log10(parseFloat(waist) - parseFloat(neck)) + 0.15456 * Math.log10(parseFloat(h))) - 450).toFixed(1);
        result = `<div class="calc-result">
          <p class="calc-result-label">Estimated Body Fat</p>
          <p class="calc-result-value">${bf}<span class="fs-16">%</span></p>
        </div>`;
      }
      content = `<div class="calc-form">
        <div class="calc-field"><label>Height (cm)</label>
          <input type="number" class="input-field" value="${h}" placeholder="175" inputmode="decimal" oninput="CalculatorsScreen.setValue('height',this.value)">
        </div>
        <div class="calc-field"><label>Waist (cm)</label>
          <input type="number" class="input-field" value="${waist}" placeholder="85" inputmode="decimal" oninput="CalculatorsScreen.setValue('waist',this.value)">
        </div>
        <div class="calc-field"><label>Neck (cm)</label>
          <input type="number" class="input-field" value="${neck}" placeholder="38" inputmode="decimal" oninput="CalculatorsScreen.setValue('neck',this.value)">
        </div>
        ${result}
      </div>`;
    } else if (id === 'macro') {
      const w = calcValues.macroWeight || '';
      const goal = calcValues.goal || 'maintain';
      let result = '';
      if (w) {
        const bw = parseFloat(w);
        const mults = { cut: { p: 2.2, c: 2, f: 0.8 }, maintain: { p: 2, c: 3, f: 1 }, bulk: { p: 2, c: 4, f: 1.2 } };
        const m = mults[goal];
        const protein = Math.round(bw * m.p);
        const carbs = Math.round(bw * m.c);
        const fat = Math.round(bw * m.f);
        const cals = protein * 4 + carbs * 4 + fat * 9;
        result = `<div class="calc-result">
          <p class="calc-result-label">Daily Target</p>
          <p class="calc-result-value">${cals} <span class="fs-16">kcal</span></p>
          <div class="calc-macros">
            <div class="calc-macro"><span class="calc-macro-label">Protein</span><span class="fw-600">${protein}g</span></div>
            <div class="calc-macro"><span class="calc-macro-label">Carbs</span><span class="fw-600">${carbs}g</span></div>
            <div class="calc-macro"><span class="calc-macro-label">Fat</span><span class="fw-600">${fat}g</span></div>
          </div>
        </div>`;
      }
      content = `<div class="calc-form">
        <div class="calc-field"><label>Body Weight (kg)</label>
          <input type="number" class="input-field" value="${w}" placeholder="80" inputmode="decimal" oninput="CalculatorsScreen.setValue('macroWeight',this.value)">
        </div>
        <div class="calc-field"><label>Goal</label>
          <div class="tab-bar">
            <button class="tab-item ${goal==='cut'?'active':''}" onclick="CalculatorsScreen.setValue('goal','cut')">Cut</button>
            <button class="tab-item ${goal==='maintain'?'active':''}" onclick="CalculatorsScreen.setValue('goal','maintain')">Maintain</button>
            <button class="tab-item ${goal==='bulk'?'active':''}" onclick="CalculatorsScreen.setValue('goal','bulk')">Bulk</button>
          </div>
        </div>
        ${result}
      </div>`;
    } else {
      content = `<div class="empty-state"><div class="empty-icon">🚧</div><h3>Coming Soon</h3><p class="text-secondary">This calculator is under development</p></div>`;
    }

    const calc = calculators.find(c => c.id === id);
    return `<div class="screen calculators-screen" id="calculators-screen">
      <div class="screen-header">${backBtn}<h1 style="flex:1;text-align:center">${calc?.name || 'Calculator'}</h1><div style="width:40px"></div></div>
      <div style="padding:0 16px">${content}</div>
    </div>`;
  }

  function openCalc(id) { activeCalc = id; calcValues = {}; refreshScreen(); }
  function back() { activeCalc = null; calcValues = {}; refreshScreen(); }
  function setValue(key, val) {
    calcValues[key] = val;
    refreshScreen();
  }

  function refreshScreen() {
    const container = document.getElementById('screen-container');
    if (container) container.innerHTML = render();
  }

  function afterRender() {}
  function cleanup() { activeCalc = null; calcValues = {}; }

  return { render, afterRender, cleanup, openCalc, back, setValue };
})();
