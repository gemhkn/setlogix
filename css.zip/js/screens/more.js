/* ============================================
   SetLogix More Screen — more.js
   ============================================ */

const MoreScreen = (() => {

  function render() {
    const user = Store.get('user');
    const history = Store.get('workoutHistory') || [];
    const settings = Store.get('settings') || {};

    const menuItems = [
      { icon: '👤', label: I18n.t('profile'), action: 'MoreScreen.showProfile()' },
      { icon: '🎯', label: I18n.t('goals'), action: 'MoreScreen.comingSoon()' },
      { icon: '🏆', label: I18n.t('achievements'), trailing: `${Math.min(history.length, 12)} ${I18n.t('badges')}`, action: 'MoreScreen.showAchievements()' },
      { icon: '📊', label: I18n.t('body_stats'), action: 'MoreScreen.comingSoon()' },
      { icon: '🔔', label: I18n.t('reminders'), action: 'MoreScreen.comingSoon()' },
      { icon: '🎨', label: I18n.t('theme'), trailing: 'Dark 🌙', action: 'MoreScreen.comingSoon()' },
      { icon: '🌐', label: I18n.t('language'), trailing: I18n.getLanguage().toUpperCase(), action: 'MoreScreen.showLanguageOptions()' },
      { icon: '💾', label: I18n.t('backup_restore'), action: 'MoreScreen.backup()' },
      { icon: '📤', label: I18n.t('export_data'), action: 'MoreScreen.exportData()' },
      { icon: '⚙️', label: I18n.t('settings'), action: 'MoreScreen.showSettings()' },
    ];

    const menuHTML = menuItems.map(item =>
      `<div class="list-item" onclick="${item.action}">
        <div class="list-item-icon">${item.icon}</div>
        <div class="list-item-content">
          <div class="list-item-title">${item.label}</div>
        </div>
        ${item.trailing ? `<span class="list-item-trailing">${item.trailing}</span>` : ''}
        <span class="list-item-arrow">›</span>
      </div>`
    ).join('');

    return `<div class="screen more-screen" id="more-screen">
      <div class="screen-header"><h1>${I18n.t('nav_more')}</h1></div>
      <div class="profile-card card">
        <div class="profile-avatar">
          <div class="avatar-circle">${user.name.charAt(0)}</div>
        </div>
        <div class="profile-info">
          <h3 class="fw-700">${user.name}</h3>
          <p class="fs-13"><span class="text-accent">⭐</span> ${user.memberType}</p>
        </div>
      </div>
      <div class="card" style="margin:0 16px;padding:0">${menuHTML}</div>
    </div>`;
  }

  function showProfile() {
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('edit_profile')}</h3>
      <div class="calc-field" style="margin-bottom:12px">
        <label>${I18n.t('name')}</label>
        <input type="text" class="input-field" id="profile-name" value="${Store.get('user.name')}">
      </div>
      <button class="btn btn-primary btn-block" onclick="MoreScreen.saveProfile()">${I18n.t('save')}</button>
      <button class="btn btn-ghost btn-block" style="margin-top:8px" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function saveProfile() {
    const name = document.getElementById('profile-name')?.value;
    if (name) {
      Store.set('user.name', name);
      Toast.show(I18n.t('profile_updated'), 'success');
      Modal.close();
      refreshScreen();
    }
  }

  function showAchievements() {
    const count = (Store.get('workoutHistory') || []).length;
    const badges = [
      { name: 'First Workout', icon: '🎖️', done: count >= 1 },
      { name: '5 Workouts', icon: '🥉', done: count >= 5 },
      { name: '10 Workouts', icon: '🥈', done: count >= 10 },
      { name: '25 Workouts', icon: '🥇', done: count >= 25 },
      { name: '50 Workouts', icon: '🏆', done: count >= 50 },
      { name: '100 Club', icon: '💎', done: count >= 100 },
    ];
    const html = badges.map(b =>
      `<div class="achievement-item ${b.done ? '' : 'locked'}">
        <span class="achievement-icon">${b.icon}</span>
        <span>${b.name}</span>
        ${b.done ? '<span class="text-success">✓</span>' : '<span class="text-muted">🔒</span>'}
      </div>`
    ).join('');
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('achievements')}</h3>
      <div>${html}</div>
      <button class="btn btn-ghost btn-block" style="margin-top:12px" onclick="Modal.close()">${I18n.t('close')}</button>
    </div>`);
  }

  function showSettings() {
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('settings')}</h3>
      <div class="list-item" style="border:none;padding:8px 0">
        <div class="list-item-content"><div class="list-item-title">${I18n.t('weight_unit')}</div></div>
        <span class="badge badge-accent">kg</span>
      </div>
      <div class="divider"></div>
      <button class="btn btn-danger btn-block" style="margin-top:12px" onclick="MoreScreen.resetData()">${I18n.t('reset_all_data')}</button>
      <button class="btn btn-ghost btn-block" style="margin-top:8px" onclick="Modal.close()">${I18n.t('close')}</button>
    </div>`);
  }

  function showLanguageOptions() {
    const current = I18n.getLanguage();
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('language')}</h3>
      <div class="list-item" onclick="MoreScreen.setLang('en')">
        <div class="list-item-content"><div class="list-item-title">English</div></div>
        ${current === 'en' ? '<span class="text-success">✓</span>' : ''}
      </div>
      <div class="list-item" onclick="MoreScreen.setLang('tr')">
        <div class="list-item-content"><div class="list-item-title">Türkçe</div></div>
        ${current === 'tr' ? '<span class="text-success">✓</span>' : ''}
      </div>
      <button class="btn btn-ghost btn-block" style="margin-top:12px" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function setLang(lang) {
    I18n.setLanguage(lang);
    Modal.close();
  }

  function resetData() {
    Modal.close();
    setTimeout(() => {
      Modal.confirm(I18n.t('reset_all_data'), I18n.t('reset_confirm'), () => {
        Store.resetAll();
        Toast.show(I18n.t('all_data_reset'), 'success');
        Router.navigate('#home');
      }, I18n.t('reset'));
    }, 350);
  }

  function backup() {
    const data = JSON.stringify(Store.get(), null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url; a.download = 'setlogix-backup.json'; a.click();
    URL.revokeObjectURL(url);
    Toast.show(I18n.t('backup_downloaded'), 'success');
  }

  function exportData() {
    backup();
  }

  function comingSoon() {
    Toast.show('Coming soon!', 'info');
  }

  function refreshScreen() {
    const container = document.getElementById('screen-container');
    if (container && Router.getCurrentScreen() === 'more') {
      container.innerHTML = render();
    }
  }

  function afterRender() {}
  function cleanup() {}

  return { render, afterRender, cleanup, showProfile, saveProfile, showAchievements,
    showSettings, showLanguageOptions, setLang, resetData, backup, exportData, comingSoon };
})();
