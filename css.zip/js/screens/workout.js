/* ============================================
   SetLogix Workout Screen — workout.js
   ============================================ */

const WorkoutScreen = (() => {
  let timerInterval = null;

  function render() {
    const session = Store.get('activeSession');
    if (!session) return renderNoSession();
    return renderActiveSession(session);
  }

  function renderNoSession() {
    return `<div class="screen workout-screen" id="workout-screen">
      <div class="screen-header"><h1>${I18n.t('nav_workout')}</h1></div>
      <div class="empty-state">
        <div class="empty-icon">🏋️</div>
        <h3>${I18n.t('no_active_workout')}</h3>
        <p class="text-secondary">${I18n.t('no_active_workout_desc')}</p>
        <button class="btn btn-primary btn-lg" style="margin-top:20px" onclick="DashboardScreen.startWorkout()">${I18n.t('start_workout')}</button>
      </div>
    </div>`;
  }

  function renderActiveSession(session) {
    const elapsed = Date.now() - session.createdAt;
    const timerStr = Render.formatDuration(elapsed);

    const exerciseCards = session.exercises.map((ex, ei) => {
      const info = Store.getExerciseInfo(ex.exerciseId);
      const lastPerf = Store.getLastPerformance(ex.exerciseId);
      const lastStr = lastPerf ? `Last: ${lastPerf.weight} kg x ${lastPerf.reps}` : '';

      const setRows = ex.sets.map((s, si) => {
        const isCompleted = s.completed;
        return `<div class="set-row ${isCompleted ? 'completed' : ''}">
          <span class="set-num">${si + 1}</span>
          <input type="number" class="set-input" value="${s.weight}" placeholder="0" 
            onchange="WorkoutScreen.updateSet(${ei},${si},'weight',this.value)" inputmode="decimal">
          <input type="number" class="set-input" value="${s.reps}" placeholder="0"
            onchange="WorkoutScreen.updateSet(${ei},${si},'reps',this.value)" inputmode="numeric">
          <input type="number" class="set-input set-input-sm" value="${s.rir}" placeholder="0"
            onchange="WorkoutScreen.updateSet(${ei},${si},'rir',this.value)" inputmode="numeric">
          <button class="set-check ${isCompleted ? 'checked' : ''}" 
            onclick="WorkoutScreen.toggleSet(${ei},${si})">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
          </button>
        </div>`;
      }).join('');

      // Current set input area (for the last incomplete set)
      const currentSetIdx = ex.sets.findIndex(s => !s.completed);
      const currentSet = currentSetIdx >= 0 ? ex.sets[currentSetIdx] : null;

      let stepperHTML = '';
      if (currentSet) {
        stepperHTML = `<div class="set-stepper-area">
          <div class="stepper-group">
            <label class="stepper-label">${I18n.t('kg')}</label>
            <div class="stepper">
              <button class="stepper-btn" onclick="WorkoutScreen.stepValue(${ei},${currentSetIdx},'weight',-2.5)">−</button>
              <input type="number" class="stepper-value" value="${currentSet.weight || ''}" placeholder="0"
                onchange="WorkoutScreen.updateSet(${ei},${currentSetIdx},'weight',this.value)" inputmode="decimal">
              <button class="stepper-btn" onclick="WorkoutScreen.stepValue(${ei},${currentSetIdx},'weight',2.5)">+</button>
            </div>
          </div>
          <div class="stepper-group">
            <label class="stepper-label">${I18n.t('reps')}</label>
            <div class="stepper">
              <button class="stepper-btn" onclick="WorkoutScreen.stepValue(${ei},${currentSetIdx},'reps',-1)">−</button>
              <input type="number" class="stepper-value" value="${currentSet.reps || ''}" placeholder="0"
                onchange="WorkoutScreen.updateSet(${ei},${currentSetIdx},'reps',this.value)" inputmode="numeric">
              <button class="stepper-btn" onclick="WorkoutScreen.stepValue(${ei},${currentSetIdx},'reps',1)">+</button>
            </div>
          </div>
          <div class="stepper-row-2">
            <div class="stepper-group stepper-group-sm">
              <label class="stepper-label">${I18n.t('rir')}</label>
              <div class="stepper">
                <button class="stepper-btn" onclick="WorkoutScreen.stepValue(${ei},${currentSetIdx},'rir',-1)">−</button>
                <input type="number" class="stepper-value" value="${currentSet.rir || ''}" placeholder="0"
                  onchange="WorkoutScreen.updateSet(${ei},${currentSetIdx},'rir',this.value)" inputmode="numeric">
                <button class="stepper-btn" onclick="WorkoutScreen.stepValue(${ei},${currentSetIdx},'rir',1)">+</button>
              </div>
            </div>
            <button class="btn btn-secondary btn-sm" onclick="WorkoutScreen.openNotes(${ei})">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7"/><path d="M18.5 2.5a2.121 2.121 0 013 3L12 15l-4 1 1-4 9.5-9.5z"/></svg>
              ${I18n.t('notes')}
            </button>
          </div>
          <button class="btn btn-primary btn-block save-set-btn" onclick="WorkoutScreen.saveSet(${ei},${currentSetIdx})">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="20 6 9 17 4 12"/></svg>
            ${I18n.t('save_set')}
          </button>
        </div>`;
      }

      return `<div class="exercise-card" id="exercise-${ei}">
        <div class="exercise-card-header">
          <div>
            <h3 class="exercise-card-title">${info.name}</h3>
            <p class="exercise-card-type">${info.type}</p>
          </div>
          <button class="btn-icon btn-ghost" onclick="WorkoutScreen.exerciseMenu(${ei})">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
          </button>
        </div>
        ${lastStr ? `<p class="exercise-last-perf">Last: ${lastPerf.weight} kg x ${lastPerf.reps}</p>` : ''}
        <div class="set-table">
          <div class="set-table-header">
            <span>${I18n.t('set')}</span><span>${I18n.t('kg')}</span><span>${I18n.t('reps')}</span><span>${I18n.t('rir')}</span><span></span>
          </div>
          ${setRows}
        </div>
        ${stepperHTML}
        <button class="btn btn-secondary btn-block btn-sm" style="margin-top:8px" onclick="WorkoutScreen.addSet(${ei})">${I18n.t('add_set')}</button>
      </div>`;
    }).join('');

    return `<div class="screen workout-screen" id="workout-screen">
      <div class="workout-header">
        <button class="btn-icon btn-ghost" onclick="Router.navigate('#home')">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polyline points="15 18 9 12 15 6"/></svg>
        </button>
        <div class="workout-header-center">
          <h2 class="workout-title">${session.name}</h2>
          <span class="workout-timer text-accent" id="workout-timer">${timerStr}</span>
        </div>
        <button class="btn-icon btn-ghost" onclick="WorkoutScreen.sessionMenu()">
          <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
        </button>
      </div>
      <div class="workout-exercises">${exerciseCards}</div>
      <div style="padding:0 16px 16px">
        <button class="btn btn-primary btn-block btn-lg" onclick="WorkoutScreen.finishWorkout()" style="margin-top:12px">${I18n.t('finish_workout')}</button>
      </div>
    </div>`;
  }

  function updateSet(ei, si, field, val) {
    const session = Store.get('activeSession');
    if (!session) return;
    const numVal = field === 'weight' ? parseFloat(val) || '' : parseInt(val) || '';
    session.exercises[ei].sets[si][field] = numVal;
    Store.set('activeSession', session);
  }

  function stepValue(ei, si, field, delta) {
    const session = Store.get('activeSession');
    if (!session) return;
    const current = parseFloat(session.exercises[ei].sets[si][field]) || 0;
    const newVal = Math.max(0, current + delta);
    session.exercises[ei].sets[si][field] = newVal;
    Store.set('activeSession', session);
    refreshScreen();
  }

  function toggleSet(ei, si) {
    const session = Store.get('activeSession');
    if (!session) return;
    session.exercises[ei].sets[si].completed = !session.exercises[ei].sets[si].completed;
    Store.set('activeSession', session);
    refreshScreen();
  }

  function saveSet(ei, si) {
    const session = Store.get('activeSession');
    if (!session) return;
    const set = session.exercises[ei].sets[si];
    if (!set.weight || !set.reps) {
      Toast.show('Enter weight and reps first', 'warning');
      return;
    }
    set.completed = true;
    Store.set('activeSession', session);
    Toast.show('Set saved! ✓', 'success');
    refreshScreen();
  }

  function addSet(ei) {
    const session = Store.get('activeSession');
    if (!session) return;
    const sets = session.exercises[ei].sets;
    const last = sets[sets.length - 1];
    session.exercises[ei].sets.push({
      weight: last?.weight || '',
      reps: last?.reps || '',
      rir: last?.rir || '',
      completed: false
    });
    Store.set('activeSession', session);
    refreshScreen();
  }

  function addExerciseToSession(exerciseId) {
    const session = Store.get('activeSession');
    if (!session) return;
    session.exercises.push({
      exerciseId,
      sets: [{ weight: '', reps: '', rir: '', completed: false }]
    });
    Store.set('activeSession', session);
    Modal.close();
    refreshScreen();
    Toast.show('Exercise added!', 'success');
  }

  function exerciseMenu(ei) {
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('exercise_options')}</h3>
      <button class="btn btn-secondary btn-block" style="margin-bottom:8px" onclick="WorkoutScreen.removeExercise(${ei})">${I18n.t('remove_exercise')}</button>
      <button class="btn btn-ghost btn-block" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function removeExercise(ei) {
    const session = Store.get('activeSession');
    if (!session) return;
    session.exercises.splice(ei, 1);
    Store.set('activeSession', session);
    Modal.close();
    refreshScreen();
  }

  function sessionMenu() {
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('session_options')}</h3>
      <button class="btn btn-secondary btn-block" style="margin-bottom:8px" onclick="WorkoutScreen.showAddExercise()">${I18n.t('add_exercise')}</button>
      <button class="btn btn-danger btn-block" style="margin-bottom:8px" onclick="WorkoutScreen.discardWorkout()">${I18n.t('discard_workout')}</button>
      <button class="btn btn-ghost btn-block" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function showAddExercise() {
    Modal.close();
    setTimeout(() => {
      const listHTML = EXERCISE_DB.map(ex => 
        `<div class="list-item" onclick="WorkoutScreen.addExerciseToSession('${ex.id}')">
          <div class="list-item-icon">${ex.icon}</div>
          <div class="list-item-content">
            <div class="list-item-title">${ex.name}</div>
            <div class="list-item-subtitle">${ex.type}</div>
          </div>
        </div>`
      ).join('');
      Modal.open(`<div class="modal-dialog modal-full">
        <h3 class="modal-dialog-title">${I18n.t('add_exercise')}</h3>
        <div class="modal-scroll">${listHTML}</div>
      </div>`);
    }, 350);
  }

  function finishWorkout() {
    Modal.confirm(I18n.t('finish_workout'), I18n.t('finish_workout_confirm'), () => {
      const ok = Store.finishWorkout();
      if (ok) {
        Toast.show('Workout saved! Great job! 🎉', 'success');
        Router.navigate('#home');
      } else {
        Toast.show('No completed sets to save', 'warning');
        Router.navigate('#home');
      }
    }, 'Finish');
  }

  function discardWorkout() {
    Modal.close();
    setTimeout(() => {
      Modal.confirm(I18n.t('discard_workout'), I18n.t('discard_workout_confirm'), () => {
        Store.discardWorkout();
        Toast.show('Workout discarded', 'info');
        Router.navigate('#home');
      }, 'Discard');
    }, 350);
  }

  function openNotes(ei) {
    Toast.show('Notes feature coming soon!', 'info');
  }

  function refreshScreen() {
    const container = document.getElementById('screen-container');
    if (container && Router.getCurrentScreen() === 'workout') {
      const html = render();
      container.innerHTML = html;
      afterRender();
    }
  }

  function startTimer() {
    stopTimer();
    timerInterval = setInterval(() => {
      const session = Store.get('activeSession');
      if (!session) { stopTimer(); return; }
      const el = document.getElementById('workout-timer');
      if (el) {
        el.textContent = Render.formatDuration(Date.now() - session.createdAt);
      }
    }, 1000);
  }

  function stopTimer() {
    if (timerInterval) { clearInterval(timerInterval); timerInterval = null; }
  }

  function afterRender() {
    const session = Store.get('activeSession');
    if (session) startTimer();
  }

  function cleanup() { stopTimer(); }

  return { render, afterRender, cleanup, updateSet, stepValue, toggleSet, saveSet, addSet,
    addExerciseToSession, exerciseMenu, removeExercise, sessionMenu, showAddExercise,
    finishWorkout, discardWorkout, openNotes };
})();
