/* ============================================
   SetLogix Program Screen — program.js
   ============================================ */

const ProgramScreen = (() => {
  let activeDay = 0;

  function render() {
    const programs = Store.get('programs') || [];
    const prog = programs[0];
    if (!prog) return renderEmpty();

    const days = prog.days;
    const day = days[activeDay] || days[0];

    const dayTabs = days.map((d, i) => 
      `<button class="day-tab ${i === activeDay ? 'active' : ''}" onclick="ProgramScreen.switchDay(${i})">${i + 1}</button>`
    ).join('') + `<button class="day-tab" onclick="ProgramScreen.addDay()">+</button>`;

    const exerciseList = day.exercises.map((ex, ei) => {
      const info = Store.getExerciseInfo(ex.exerciseId);
      return `<div class="program-exercise-item">
        <div class="program-exercise-icon">${info.icon}</div>
        <div class="program-exercise-content">
          <div class="program-exercise-name">${info.name}</div>
          <div class="program-exercise-detail">${ex.sets} sets x ${ex.reps} reps</div>
        </div>
        <button class="btn-icon btn-ghost" onclick="ProgramScreen.exerciseMenu(${ei})">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
        </button>
      </div>`;
    }).join('');

    return `<div class="screen program-screen" id="program-screen">
      <div class="screen-header">
        <h1>${I18n.t('program')}</h1>
        <button class="btn-ghost text-accent fw-600" onclick="ProgramScreen.editProgram()">${I18n.t('edit')}</button>
      </div>
      <div class="program-info-card card">
        <div class="flex-between">
          <div>
            <h3 class="fw-600">${prog.name}</h3>
            <p class="fs-12 text-secondary">${prog.type}</p>
          </div>
          <button class="btn-icon btn-ghost">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="9" y="9" width="13" height="13" rx="2" ry="2"/><path d="M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1"/></svg>
          </button>
        </div>
      </div>
      <div class="day-tabs">${dayTabs}</div>
      <div class="program-day-header" style="display:flex; justify-content:space-between; align-items:center;">
        <div>
          <h3>${day.name}</h3>
          <p class="fs-13 text-secondary">${day.exercises.length} ${I18n.t('exercises')}</p>
        </div>
        <button class="btn-icon btn-ghost" onclick="ProgramScreen.dayMenu()">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="5" r="2"/><circle cx="12" cy="12" r="2"/><circle cx="12" cy="19" r="2"/></svg>
        </button>
      </div>
      <div class="program-exercise-list">${exerciseList}</div>
      <button class="btn btn-outline btn-block" onclick="ProgramScreen.addExercise()">${I18n.t('add_exercise')}</button>
    </div>`;
  }

  function renderEmpty() {
    return `<div class="screen program-screen" id="program-screen">
      <div class="screen-header"><h1>${I18n.t('program')}</h1></div>
      <div class="empty-state">
        <div class="empty-icon">📋</div>
        <h3>No Programs</h3>
        <p class="text-secondary">Create your first training program</p>
        <button class="btn btn-primary" style="margin-top:16px" onclick="ProgramScreen.createProgram()">Create Program</button>
      </div>
    </div>`;
  }

  function switchDay(idx) {
    activeDay = idx;
    refreshScreen();
  }

  function addExercise() {
    const listHTML = EXERCISE_DB.map(ex => 
      `<div class="list-item" onclick="ProgramScreen.addExerciseToDay('${ex.id}')">
        <div class="list-item-icon">${ex.icon}</div>
        <div class="list-item-content">
          <div class="list-item-title">${ex.name}</div>
          <div class="list-item-subtitle">${ex.type} · ${ex.muscle}</div>
        </div>
      </div>`
    ).join('');
    Modal.open(`<div class="modal-dialog modal-full">
      <h3 class="modal-dialog-title">${I18n.t('add_exercise')}</h3>
      <div class="modal-scroll">${listHTML}</div>
    </div>`);
  }

  function addExerciseToDay(exerciseId) {
    const programs = Store.get('programs');
    programs[0].days[activeDay].exercises.push({
      exerciseId, sets: '3', reps: '8-12', notes: ''
    });
    Store.set('programs', programs);
    Modal.close();
    refreshScreen();
    Toast.show('Exercise added!', 'success');
  }

  function exerciseMenu(ei) {
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('exercise_options')}</h3>
      <button class="btn btn-danger btn-block" style="margin-bottom:8px" onclick="ProgramScreen.removeExercise(${ei})">${I18n.t('remove')}</button>
      <button class="btn btn-ghost btn-block" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function removeExercise(ei) {
    const programs = Store.get('programs');
    programs[0].days[activeDay].exercises.splice(ei, 1);
    Store.set('programs', programs);
    Modal.close();
    refreshScreen();
  }

  function editProgram() {
    const programs = Store.get('programs');
    const prog = programs[0];
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('edit_program')}</h3>
      <div style="margin-bottom: 12px;">
        <label class="fs-12 text-secondary" style="display:block; margin-bottom:4px;">${I18n.t('program_name')}</label>
        <input type="text" id="edit-program-name" class="form-control" value="${prog.name}" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-tertiary); color: var(--text-primary);">
      </div>
      <div style="margin-bottom: 16px;">
        <label class="fs-12 text-secondary" style="display:block; margin-bottom:4px;">${I18n.t('program_type')}</label>
        <input type="text" id="edit-program-type" class="form-control" value="${prog.type}" style="width: 100%; padding: 12px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-tertiary); color: var(--text-primary);">
      </div>
      <button class="btn btn-primary btn-block" style="margin-bottom:8px" onclick="ProgramScreen.saveProgram()">${I18n.t('save')}</button>
      <button class="btn btn-ghost btn-block" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function saveProgram() {
    const nameInput = document.getElementById('edit-program-name');
    const typeInput = document.getElementById('edit-program-type');
    
    if (nameInput && typeInput && nameInput.value.trim() && typeInput.value.trim()) {
      const programs = Store.get('programs');
      programs[0].name = nameInput.value.trim();
      programs[0].type = typeInput.value.trim();
      Store.set('programs', programs);
      Modal.close();
      refreshScreen();
    } else {
      Toast.show('Fields cannot be empty!', 'error');
    }
  }
  function createProgram() { Toast.show('Program creator coming soon!', 'info'); }

  function addDay() {
    const programs = Store.get('programs');
    const newDayName = `${I18n.t('new_day')} ${programs[0].days.length + 1}`;
    programs[0].days.push({
      id: 'd' + Date.now(),
      name: newDayName,
      exercises: []
    });
    Store.set('programs', programs);
    activeDay = programs[0].days.length - 1;
    refreshScreen();
  }

  function dayMenu() {
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('day_options')}</h3>
      <button class="btn btn-outline btn-block" style="margin-bottom:8px" onclick="ProgramScreen.renameDay()">${I18n.t('rename_day')}</button>
      <button class="btn btn-danger btn-block" style="margin-bottom:8px" onclick="ProgramScreen.deleteDay()">${I18n.t('delete_day')}</button>
      <button class="btn btn-ghost btn-block" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function renameDay() {
    const programs = Store.get('programs');
    const day = programs[0].days[activeDay];
    Modal.open(`<div class="modal-dialog">
      <h3 class="modal-dialog-title">${I18n.t('rename_day')}</h3>
      <input type="text" id="rename-day-input" class="form-control" value="${day.name}" style="margin-bottom: 16px; width: 100%; padding: 12px; border-radius: 8px; border: 1px solid var(--border-color); background: var(--bg-tertiary); color: var(--text-primary);">
      <button class="btn btn-primary btn-block" style="margin-bottom:8px" onclick="ProgramScreen.saveDayName()">${I18n.t('save')}</button>
      <button class="btn btn-ghost btn-block" onclick="Modal.close()">${I18n.t('cancel')}</button>
    </div>`);
  }

  function saveDayName() {
    const input = document.getElementById('rename-day-input');
    if (input && input.value.trim()) {
      const programs = Store.get('programs');
      programs[0].days[activeDay].name = input.value.trim();
      Store.set('programs', programs);
      Modal.close();
      refreshScreen();
    }
  }

  function deleteDay() {
    const programs = Store.get('programs');
    if (programs[0].days.length <= 1) {
      Toast.show('Cannot delete the last day!', 'error');
      return;
    }
    programs[0].days.splice(activeDay, 1);
    if (activeDay >= programs[0].days.length) {
      activeDay = programs[0].days.length - 1;
    }
    Store.set('programs', programs);
    Modal.close();
    refreshScreen();
  }

  function refreshScreen() {
    const container = document.getElementById('screen-container');
    if (container && Router.getCurrentScreen() === 'program') {
      container.innerHTML = render();
    }
  }

  function afterRender() {}
  function cleanup() { activeDay = 0; }

  return { render, afterRender, cleanup, switchDay, addExercise, addExerciseToDay,
    exerciseMenu, removeExercise, editProgram, saveProgram, createProgram,
    addDay, dayMenu, renameDay, saveDayName, deleteDay };
})();
