/* ============================================
   Exercise Database
   ============================================ */
const EXERCISE_DB = [
  // Chest
  { id: 'bench-press', name: 'Bench Press', muscle: 'Chest', type: 'Barbell', icon: '🏋️' },
  { id: 'incline-dumbbell-press', name: 'Incline Dumbbell Press', muscle: 'Chest', type: 'Dumbbell', icon: '🏋️' },
  { id: 'decline-bench-press', name: 'Decline Bench Press', muscle: 'Chest', type: 'Barbell', icon: '🏋️' },
  { id: 'cable-fly', name: 'Cable Fly', muscle: 'Chest', type: 'Cable', icon: '🏋️' },
  { id: 'push-up', name: 'Push Up', muscle: 'Chest', type: 'Bodyweight', icon: '🤸' },
  { id: 'dumbbell-fly', name: 'Dumbbell Fly', muscle: 'Chest', type: 'Dumbbell', icon: '🏋️' },
  { id: 'chest-dip', name: 'Chest Dip', muscle: 'Chest', type: 'Bodyweight', icon: '🤸' },
  { id: 'machine-chest-press', name: 'Machine Chest Press', muscle: 'Chest', type: 'Machine', icon: '🏋️' },

  // Back
  { id: 'deadlift', name: 'Deadlift', muscle: 'Back', type: 'Barbell', icon: '🏋️' },
  { id: 'barbell-row', name: 'Barbell Row', muscle: 'Back', type: 'Barbell', icon: '🏋️' },
  { id: 'pull-up', name: 'Pull Up', muscle: 'Back', type: 'Bodyweight', icon: '🤸' },
  { id: 'lat-pulldown', name: 'Lat Pulldown', muscle: 'Back', type: 'Cable', icon: '🏋️' },
  { id: 'seated-cable-row', name: 'Seated Cable Row', muscle: 'Back', type: 'Cable', icon: '🏋️' },
  { id: 'dumbbell-row', name: 'Dumbbell Row', muscle: 'Back', type: 'Dumbbell', icon: '🏋️' },
  { id: 't-bar-row', name: 'T-Bar Row', muscle: 'Back', type: 'Barbell', icon: '🏋️' },
  { id: 'face-pull', name: 'Face Pull', muscle: 'Back', type: 'Cable', icon: '🏋️' },

  // Legs
  { id: 'squat', name: 'Squat', muscle: 'Legs', type: 'Barbell', icon: '🏋️' },
  { id: 'leg-press', name: 'Leg Press', muscle: 'Legs', type: 'Machine', icon: '🏋️' },
  { id: 'romanian-deadlift', name: 'Romanian Deadlift', muscle: 'Legs', type: 'Barbell', icon: '🏋️' },
  { id: 'leg-curl', name: 'Leg Curl', muscle: 'Legs', type: 'Machine', icon: '🏋️' },
  { id: 'leg-extension', name: 'Leg Extension', muscle: 'Legs', type: 'Machine', icon: '🏋️' },
  { id: 'lunges', name: 'Lunges', muscle: 'Legs', type: 'Dumbbell', icon: '🏋️' },
  { id: 'calf-raise', name: 'Calf Raise', muscle: 'Legs', type: 'Machine', icon: '🏋️' },
  { id: 'bulgarian-split-squat', name: 'Bulgarian Split Squat', muscle: 'Legs', type: 'Dumbbell', icon: '🏋️' },
  { id: 'hack-squat', name: 'Hack Squat', muscle: 'Legs', type: 'Machine', icon: '🏋️' },
  { id: 'hip-thrust', name: 'Hip Thrust', muscle: 'Legs', type: 'Barbell', icon: '🏋️' },

  // Shoulder
  { id: 'shoulder-press', name: 'Shoulder Press', muscle: 'Shoulder', type: 'Barbell', icon: '🏋️' },
  { id: 'lateral-raise', name: 'Lateral Raise', muscle: 'Shoulder', type: 'Dumbbell', icon: '🏋️' },
  { id: 'front-raise', name: 'Front Raise', muscle: 'Shoulder', type: 'Dumbbell', icon: '🏋️' },
  { id: 'rear-delt-fly', name: 'Rear Delt Fly', muscle: 'Shoulder', type: 'Dumbbell', icon: '🏋️' },
  { id: 'arnold-press', name: 'Arnold Press', muscle: 'Shoulder', type: 'Dumbbell', icon: '🏋️' },
  { id: 'upright-row', name: 'Upright Row', muscle: 'Shoulder', type: 'Barbell', icon: '🏋️' },

  // Arms
  { id: 'bicep-curl', name: 'Bicep Curl', muscle: 'Arms', type: 'Dumbbell', icon: '💪' },
  { id: 'hammer-curl', name: 'Hammer Curl', muscle: 'Arms', type: 'Dumbbell', icon: '💪' },
  { id: 'triceps-pushdown', name: 'Triceps Pushdown', muscle: 'Arms', type: 'Cable', icon: '💪' },
  { id: 'skull-crusher', name: 'Skull Crusher', muscle: 'Arms', type: 'Barbell', icon: '💪' },
  { id: 'dips', name: 'Dips', muscle: 'Arms', type: 'Bodyweight', icon: '🤸' },
  { id: 'preacher-curl', name: 'Preacher Curl', muscle: 'Arms', type: 'Barbell', icon: '💪' },
  { id: 'cable-curl', name: 'Cable Curl', muscle: 'Arms', type: 'Cable', icon: '💪' },
  { id: 'overhead-tricep-extension', name: 'Overhead Tricep Extension', muscle: 'Arms', type: 'Dumbbell', icon: '💪' },

  // Core
  { id: 'plank', name: 'Plank', muscle: 'Core', type: 'Bodyweight', icon: '🧘' },
  { id: 'crunches', name: 'Crunches', muscle: 'Core', type: 'Bodyweight', icon: '🧘' },
  { id: 'hanging-leg-raise', name: 'Hanging Leg Raise', muscle: 'Core', type: 'Bodyweight', icon: '🧘' },
  { id: 'cable-crunch', name: 'Cable Crunch', muscle: 'Core', type: 'Cable', icon: '🧘' },
  { id: 'russian-twist', name: 'Russian Twist', muscle: 'Core', type: 'Bodyweight', icon: '🧘' },
  { id: 'ab-wheel', name: 'Ab Wheel', muscle: 'Core', type: 'Bodyweight', icon: '🧘' },
];

const MUSCLE_GROUPS = ['All', 'Chest', 'Back', 'Legs', 'Shoulder', 'Arms', 'Core'];
