/* ============================================
   SetLogix Router — router.js
   Hash-based SPA navigation
   ============================================ */

const Router = (() => {
  const screens = {};
  let currentScreen = null;
  let currentRoute = '';

  const ROUTES = {
    '#home': 'dashboard',
    '#workout': 'workout',
    '#program': 'program',
    '#progress': 'progress',
    '#exercises': 'exercises',
    '#calculators': 'calculators',
    '#more': 'more',
  };

  const NAV_ROUTES = ['#home', '#workout', '#program', '#progress', '#more'];

  function register(name, screenModule) {
    screens[name] = screenModule;
  }

  function navigate(hash) {
    if (!hash || !ROUTES[hash]) {
      hash = '#home';
    }
    if (window.location.hash !== hash) {
      window.location.hash = hash;
    } else {
      render(hash);
    }
  }

  function render(hash) {
    const screenName = ROUTES[hash] || 'dashboard';
    const screen = screens[screenName];
    if (!screen) {
      console.warn('[Router] Screen not found:', screenName);
      return;
    }

    currentRoute = hash;
    currentScreen = screenName;

    const container = document.getElementById('screen-container');
    if (container) {
      // Cleanup previous screen
      if (screen.cleanup) screen.cleanup();

      // Render new screen
      const html = screen.render();
      container.innerHTML = html;

      // Post-render hooks (attach event listeners)
      if (screen.afterRender) {
        requestAnimationFrame(() => screen.afterRender());
      }
    }

    // Update navbar
    Navbar.update(hash);
  }

  function getCurrentRoute() {
    return currentRoute;
  }

  function getCurrentScreen() {
    return currentScreen;
  }

  function init() {
    window.addEventListener('hashchange', () => {
      render(window.location.hash);
    });

    const initialHash = window.location.hash || '#home';
    navigate(initialHash);
  }

  return { register, navigate, render, init, getCurrentRoute, getCurrentScreen, NAV_ROUTES };
})();
