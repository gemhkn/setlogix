/* ============================================
   SetLogix Modal — modal.js
   ============================================ */

const Modal = (() => {
  let isOpen = false;

  function open(contentHTML, options = {}) {
    const overlay = document.getElementById('modal-overlay');
    const content = document.getElementById('modal-content');
    if (!overlay || !content) return;

    content.innerHTML = contentHTML;
    overlay.classList.remove('hidden');
    isOpen = true;

    requestAnimationFrame(() => {
      overlay.classList.add('modal-active');
    });

    // Close on overlay click
    if (options.closeable !== false) {
      overlay.onclick = (e) => {
        if (e.target === overlay) close();
      };
    }
  }

  function close() {
    const overlay = document.getElementById('modal-overlay');
    if (!overlay) return;

    overlay.classList.remove('modal-active');
    isOpen = false;

    setTimeout(() => {
      overlay.classList.add('hidden');
      const content = document.getElementById('modal-content');
      if (content) content.innerHTML = '';
    }, 300);
  }

  function confirm(title, message, onConfirm, confirmText = 'Confirm') {
    const html = `
      <div class="modal-dialog">
        <h3 class="modal-dialog-title">${title}</h3>
        <p class="modal-dialog-message">${message}</p>
        <div class="modal-dialog-actions">
          <button class="btn btn-secondary" onclick="Modal.close()">Cancel</button>
          <button class="btn btn-primary" id="modal-confirm-btn">${confirmText}</button>
        </div>
      </div>
    `;

    open(html);

    requestAnimationFrame(() => {
      const confirmBtn = document.getElementById('modal-confirm-btn');
      if (confirmBtn) {
        confirmBtn.onclick = () => {
          close();
          if (onConfirm) onConfirm();
        };
      }
    });
  }

  return { open, close, confirm, isOpen: () => isOpen };
})();
