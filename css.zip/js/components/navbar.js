/* ============================================
   SetLogix Bottom Navigation — navbar.js
   ============================================ */

const Navbar = (() => {
  const navItems = [
    { hash: '#home', label: 'Home', icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 01-2 2H5a2 2 0 01-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>` },
    { hash: '#workout', label: 'Workout', icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M6.5 6.5L17.5 17.5"/><path d="M2 12h4M18 12h4"/><path d="M6 8v8M18 8v8"/><path d="M9 6v12M15 6v12"/></svg>` },
    { hash: '#program', label: 'Program', icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"/><line x1="3" y1="9" x2="21" y2="9"/><line x1="9" y1="21" x2="9" y2="9"/></svg>` },
    { hash: '#progress', label: 'Progress', icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>` },
    { hash: '#more', label: 'More', icon: `<svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="3" y1="12" x2="21" y2="12"/><line x1="3" y1="6" x2="21" y2="6"/><line x1="3" y1="18" x2="21" y2="18"/></svg>` },
  ];

  function render() {
    const nav = document.getElementById('bottom-nav');
    if (!nav) return;

    const currentHash = window.location.hash || '#home';

    nav.innerHTML = navItems.map(item => `
      <button class="nav-item ${currentHash === item.hash ? 'active' : ''}" 
              onclick="Router.navigate('${item.hash}')"
              id="nav-${item.hash.slice(1)}">
        <span class="nav-icon">${item.icon}</span>
        <span class="nav-label">${I18n.t('nav_' + item.hash.slice(1))}</span>
      </button>
    `).join('');
  }

  function update(hash) {
    const items = document.querySelectorAll('.nav-item');
    items.forEach(item => {
      const itemHash = '#' + item.id.replace('nav-', '');
      item.classList.toggle('active', itemHash === hash);
    });
  }

  return { render, update };
})();
