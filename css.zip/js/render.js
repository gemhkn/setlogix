/* ============================================
   SetLogix DOM Render Engine — render.js
   ============================================ */

const Render = (() => {
  /**
   * Efficiently update a container's innerHTML.
   * Uses a temporary element to diff and patch the DOM.
   */
  function updateContainer(container, newHTML) {
    if (!container) return;

    // If empty, just set
    if (!container.innerHTML.trim()) {
      container.innerHTML = newHTML;
      return;
    }

    // Create a temporary container for the new DOM
    const temp = document.createElement('div');
    temp.innerHTML = newHTML;

    // Reconcile children
    reconcileChildren(container, temp);
  }

  function reconcileChildren(existing, incoming) {
    const existingChildren = Array.from(existing.childNodes);
    const incomingChildren = Array.from(incoming.childNodes);

    const max = Math.max(existingChildren.length, incomingChildren.length);

    for (let i = 0; i < max; i++) {
      const existNode = existingChildren[i];
      const newNode = incomingChildren[i];

      if (!existNode && newNode) {
        // New node
        existing.appendChild(newNode.cloneNode(true));
      } else if (existNode && !newNode) {
        // Remove extra node
        existing.removeChild(existNode);
      } else if (existNode && newNode) {
        // Both exist: compare
        if (existNode.nodeType !== newNode.nodeType || existNode.nodeName !== newNode.nodeName) {
          existing.replaceChild(newNode.cloneNode(true), existNode);
        } else if (existNode.nodeType === Node.TEXT_NODE) {
          if (existNode.textContent !== newNode.textContent) {
            existNode.textContent = newNode.textContent;
          }
        } else if (existNode.nodeType === Node.ELEMENT_NODE) {
          // Skip focused input elements to prevent cursor jump
          if (isFocusedInput(existNode)) {
            continue;
          }

          // Update attributes
          updateAttributes(existNode, newNode);

          // Recursively reconcile children
          reconcileChildren(existNode, newNode);
        }
      }
    }
  }

  function isFocusedInput(el) {
    if (document.activeElement === el) {
      const tag = el.tagName.toLowerCase();
      return tag === 'input' || tag === 'textarea' || tag === 'select';
    }
    // Check if active element is a descendant
    if (el.contains && el.contains(document.activeElement)) {
      const tag = document.activeElement.tagName.toLowerCase();
      return tag === 'input' || tag === 'textarea' || tag === 'select';
    }
    return false;
  }

  function updateAttributes(existing, incoming) {
    // Remove old attributes not in new
    const existAttrs = Array.from(existing.attributes);
    for (const attr of existAttrs) {
      if (!incoming.hasAttribute(attr.name)) {
        existing.removeAttribute(attr.name);
      }
    }
    // Set new/changed attributes
    const newAttrs = Array.from(incoming.attributes);
    for (const attr of newAttrs) {
      if (existing.getAttribute(attr.name) !== attr.value) {
        existing.setAttribute(attr.name, attr.value);
      }
    }
  }

  /**
   * Simple render: just set innerHTML (for initial renders)
   */
  function render(container, html) {
    if (!container) return;
    container.innerHTML = html;
  }

  /**
   * Format duration in seconds to HH:MM:SS
   */
  function formatDuration(ms) {
    const totalSeconds = Math.floor(ms / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    const pad = n => String(n).padStart(2, '0');
    return `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  }

  /**
   * Format date
   */
  function formatDate(timestamp) {
    const d = new Date(timestamp);
    const months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${months[d.getMonth()]} ${d.getDate()}, ${d.getFullYear()}`;
  }

  /**
   * Format relative time
   */
  function timeAgo(timestamp) {
    const diff = Date.now() - timestamp;
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(diff / 3600000);
    const days = Math.floor(diff / 86400000);

    if (minutes < 1) return 'Just now';
    if (minutes < 60) return `${minutes}m ago`;
    if (hours < 24) return `${hours}h ago`;
    if (days < 7) return `${days}d ago`;
    return formatDate(timestamp);
  }

  return { updateContainer, render, formatDuration, formatDate, timeAgo };
})();
