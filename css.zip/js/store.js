/* ============================================
   SetLogix State Management — store.js
   Immutable state with pub/sub and localStorage
   ============================================ */

const Store = (() => {
  const STORAGE_KEY = 'setlogix_state';
  const listeners = new Map();
  let state = {};

  // --- Default State ---
  const defaultState = {
    user: {
      name: 'Alex',
      email: 'alex@setlogix.app',
      memberType: 'Premium Member',
      avatar: null,
    },
    activeSession: null,
    workoutHistory: [],
    programs: [
      {
        id: 'prog-1',
        name: 'Strength Builder',
        type: '4 Days Split',
        days: [
          {
            id: 'day-1',
            name: 'Day 1 – Push',
            exercises: [
              { exerciseId: 'bench-press', sets: '4', reps: '6-10', notes: '' },
              { exerciseId: 'incline-dumbbell-press', sets: '3', reps: '8-12', notes: '' },
              { exerciseId: 'shoulder-press', sets: '3', reps: '6-10', notes: '' },
              { exerciseId: 'dips', sets: '3', reps: '8-12', notes: '' },
              { exerciseId: 'lateral-raise', sets: '3', reps: '12-15', notes: '' },
              { exerciseId: 'triceps-pushdown', sets: '3', reps: '10-15', notes: '' },
            ]
          },
          {
            id: 'day-2',
            name: 'Day 2 – Pull',
            exercises: [
              { exerciseId: 'deadlift', sets: '4', reps: '5-8', notes: '' },
              { exerciseId: 'barbell-row', sets: '4', reps: '6-10', notes: '' },
              { exerciseId: 'lat-pulldown', sets: '3', reps: '8-12', notes: '' },
              { exerciseId: 'seated-cable-row', sets: '3', reps: '10-12', notes: '' },
              { exerciseId: 'bicep-curl', sets: '3', reps: '10-12', notes: '' },
              { exerciseId: 'hammer-curl', sets: '3', reps: '10-12', notes: '' },
            ]
          },
          {
            id: 'day-3',
            name: 'Day 3 – Legs',
            exercises: [
              { exerciseId: 'squat', sets: '4', reps: '5-8', notes: '' },
              { exerciseId: 'leg-press', sets: '3', reps: '8-12', notes: '' },
              { exerciseId: 'romanian-deadlift', sets: '3', reps: '8-10', notes: '' },
              { exerciseId: 'leg-curl', sets: '3', reps: '10-12', notes: '' },
              { exerciseId: 'leg-extension', sets: '3', reps: '10-12', notes: '' },
              { exerciseId: 'calf-raise', sets: '4', reps: '12-15', notes: '' },
            ]
          },
          {
            id: 'day-4',
            name: 'Day 4 – Upper',
            exercises: [
              { exerciseId: 'shoulder-press', sets: '4', reps: '6-10', notes: '' },
              { exerciseId: 'incline-dumbbell-press', sets: '3', reps: '8-12', notes: '' },
              { exerciseId: 'barbell-row', sets: '3', reps: '8-10', notes: '' },
              { exerciseId: 'lateral-raise', sets: '3', reps: '12-15', notes: '' },
              { exerciseId: 'triceps-pushdown', sets: '3', reps: '10-15', notes: '' },
              { exerciseId: 'bicep-curl', sets: '3', reps: '10-12', notes: '' },
            ]
          }
        ]
      }
    ],
    favorites: ['bench-press', 'squat', 'deadlift'],
    settings: {
      theme: 'dark',
      weightUnit: 'kg',
      notifications: true,
    },
  };

  // --- Seed workout history for realistic data ---
  function generateSeedHistory() {
    const history = [];
    const now = Date.now();
    const dayMs = 86400000;

    const workouts = [
      {
        name: 'Push Day',
        programDayId: 'day-1',
        exercises: [
          { exerciseId: 'bench-press', sets: [
            { weight: 60, reps: 12, rir: 2, completed: true },
            { weight: 70, reps: 10, rir: 1, completed: true },
            { weight: 80, reps: 8, rir: 1, completed: true },
            { weight: 82.5, reps: 6, rir: 1, completed: true },
          ]},
          { exerciseId: 'incline-dumbbell-press', sets: [
            { weight: 30, reps: 10, rir: 2, completed: true },
            { weight: 30, reps: 10, rir: 1, completed: true },
            { weight: 30, reps: 8, rir: 1, completed: true },
          ]},
          { exerciseId: 'shoulder-press', sets: [
            { weight: 40, reps: 10, rir: 2, completed: true },
            { weight: 45, reps: 8, rir: 1, completed: true },
            { weight: 45, reps: 7, rir: 1, completed: true },
          ]},
        ]
      },
      {
        name: 'Pull Day',
        programDayId: 'day-2',
        exercises: [
          { exerciseId: 'deadlift', sets: [
            { weight: 100, reps: 5, rir: 2, completed: true },
            { weight: 120, reps: 5, rir: 1, completed: true },
            { weight: 140, reps: 3, rir: 0, completed: true },
          ]},
          { exerciseId: 'barbell-row', sets: [
            { weight: 60, reps: 10, rir: 2, completed: true },
            { weight: 70, reps: 8, rir: 1, completed: true },
            { weight: 80, reps: 8, rir: 1, completed: true },
          ]},
        ]
      },
      {
        name: 'Leg Day',
        programDayId: 'day-3',
        exercises: [
          { exerciseId: 'squat', sets: [
            { weight: 80, reps: 8, rir: 2, completed: true },
            { weight: 100, reps: 5, rir: 1, completed: true },
            { weight: 120, reps: 5, rir: 0, completed: true },
          ]},
          { exerciseId: 'leg-press', sets: [
            { weight: 150, reps: 10, rir: 2, completed: true },
            { weight: 180, reps: 8, rir: 1, completed: true },
            { weight: 180, reps: 8, rir: 1, completed: true },
          ]},
        ]
      },
    ];

    // Generate ~16 workouts over the past month
    for (let i = 0; i < 16; i++) {
      const daysAgo = Math.floor(i * 2) + (i > 3 ? 1 : 0);
      const workout = workouts[i % workouts.length];
      const completedAt = now - (daysAgo * dayMs) - Math.random() * dayMs * 0.3;
      const createdAt = completedAt - (45 + Math.random() * 30) * 60000;
      history.push({
        id: `workout-${i}`,
        name: workout.name,
        programDayId: workout.programDayId,
        createdAt,
        completedAt,
        duration: completedAt - createdAt,
        exercises: JSON.parse(JSON.stringify(workout.exercises)),
      });
    }

    return history;
  }

  // --- Load from localStorage ---
  function load() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        state = deepMerge(defaultState, parsed);
      } else {
        state = JSON.parse(JSON.stringify(defaultState));
        state.workoutHistory = generateSeedHistory();
        save();
      }
    } catch (e) {
      console.warn('[Store] Failed to load state, using defaults:', e);
      state = JSON.parse(JSON.stringify(defaultState));
      state.workoutHistory = generateSeedHistory();
      save();
    }
  }

  // --- Save to localStorage ---
  function save() {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
    } catch (e) {
      console.warn('[Store] Failed to save state:', e);
    }
  }

  // --- Deep merge helper ---
  function deepMerge(target, source) {
    const result = { ...target };
    for (const key in source) {
      if (source[key] && typeof source[key] === 'object' && !Array.isArray(source[key]) && target[key]) {
        result[key] = deepMerge(target[key], source[key]);
      } else {
        result[key] = source[key];
      }
    }
    return result;
  }

  // --- Deep clone ---
  function clone(obj) {
    return JSON.parse(JSON.stringify(obj));
  }

  // --- Public API ---
  return {
    getStreak() {
      const history = state.workoutHistory || [];
      if (history.length === 0) return 0;
      
      const workedDays = new Set();
      history.forEach(w => {
        if (w.completedAt) {
          const date = new Date(w.completedAt);
          date.setHours(0,0,0,0);
          workedDays.add(date.getTime());
        }
      });
      
      const sortedDays = Array.from(workedDays).sort((a,b) => b - a);
      const today = new Date();
      today.setHours(0,0,0,0);
      const todayTime = today.getTime();
      const yesterdayTime = todayTime - 86400000;
      
      let streak = 0;
      if (sortedDays[0] === todayTime || sortedDays[0] === yesterdayTime) {
        streak = 1;
        let curr = sortedDays[0];
        for (let i = 1; i < sortedDays.length; i++) {
          if (sortedDays[i] === curr - 86400000) {
            streak++;
            curr -= 86400000;
          } else {
            break;
          }
        }
      }
      return streak;
    },

    init() {
      load();
      return state;
    },

    get(path) {
      if (!path) return clone(state);
      const keys = path.split('.');
      let val = state;
      for (const k of keys) {
        if (val == null) return undefined;
        val = val[k];
      }
      return val !== undefined ? clone(val) : undefined;
    },

    set(path, value) {
      const keys = path.split('.');
      let obj = state;
      for (let i = 0; i < keys.length - 1; i++) {
        if (!obj[keys[i]] || typeof obj[keys[i]] !== 'object') {
          obj[keys[i]] = {};
        }
        obj = obj[keys[i]];
      }
      obj[keys[keys.length - 1]] = typeof value === 'object' ? clone(value) : value;
      save();
      this.notify(path);
    },

    update(path, updater) {
      const current = this.get(path);
      const next = updater(current);
      this.set(path, next);
    },

    subscribe(path, callback) {
      if (!listeners.has(path)) {
        listeners.set(path, new Set());
      }
      listeners.get(path).add(callback);
      return () => listeners.get(path)?.delete(callback);
    },

    notify(changedPath) {
      listeners.forEach((callbacks, subscribedPath) => {
        if (changedPath.startsWith(subscribedPath) || subscribedPath.startsWith(changedPath) || subscribedPath === '*') {
          callbacks.forEach(cb => {
            try { cb(this.get(subscribedPath)); }
            catch (e) { console.error('[Store] Listener error:', e); }
          });
        }
      });
    },

    // --- Workout Helpers ---
    startWorkout(programDayId, workoutName, exercises) {
      if (state.activeSession) {
        console.warn('[Store] Active session already exists, cannot start new one.');
        return false;
      }
      const session = {
        id: 'session-' + Date.now(),
        programDayId,
        name: workoutName,
        createdAt: Date.now(),
        exercises: exercises.map(ex => ({
          exerciseId: ex.exerciseId,
          sets: [{ weight: '', reps: '', rir: '', completed: false }],
        })),
      };
      this.set('activeSession', session);
      return true;
    },

    finishWorkout() {
      const session = this.get('activeSession');
      if (!session) return false;

      // Filter out empty sets
      const cleanExercises = session.exercises
        .map(ex => ({
          ...ex,
          sets: ex.sets.filter(s => s.weight && s.reps && s.completed),
        }))
        .filter(ex => ex.sets.length > 0);

      if (cleanExercises.length === 0) {
        this.set('activeSession', null);
        return false;
      }

      const record = {
        id: 'workout-' + Date.now(),
        name: session.name,
        programDayId: session.programDayId,
        createdAt: session.createdAt,
        completedAt: Date.now(),
        duration: Date.now() - session.createdAt,
        exercises: cleanExercises,
      };

      this.update('workoutHistory', history => [record, ...history]);
      this.set('activeSession', null);
      return true;
    },

    discardWorkout() {
      this.set('activeSession', null);
    },

    getExerciseInfo(exerciseId) {
      return EXERCISE_DB.find(e => e.id === exerciseId) || { name: exerciseId, type: 'Unknown', muscle: 'Unknown', icon: '🏋️' };
    },

    getPersonalRecord(exerciseId) {
      const history = state.workoutHistory || [];
      let maxWeight = 0;
      let maxReps = 0;
      for (const w of history) {
        for (const ex of w.exercises) {
          if (ex.exerciseId === exerciseId) {
            for (const s of ex.sets) {
              if (s.weight > maxWeight) {
                maxWeight = s.weight;
                maxReps = s.reps;
              } else if (s.weight === maxWeight && s.reps > maxReps) {
                maxReps = s.reps;
              }
            }
          }
        }
      }
      return maxWeight > 0 ? { weight: maxWeight, reps: maxReps } : null;
    },

    getLastPerformance(exerciseId) {
      const history = state.workoutHistory || [];
      for (const w of history) {
        for (const ex of w.exercises) {
          if (ex.exerciseId === exerciseId && ex.sets.length > 0) {
            const best = ex.sets.reduce((a, b) => (b.weight > a.weight ? b : a), ex.sets[0]);
            return { weight: best.weight, reps: best.reps };
          }
        }
      }
      return null;
    },

    getThisWeekWorkouts() {
      const now = new Date();
      const startOfWeek = new Date(now);
      startOfWeek.setDate(now.getDate() - now.getDay() + 1); // Monday
      startOfWeek.setHours(0, 0, 0, 0);
      return (state.workoutHistory || []).filter(w => w.completedAt >= startOfWeek.getTime());
    },

    getThisMonthWorkouts() {
      const now = new Date();
      const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1).getTime();
      return (state.workoutHistory || []).filter(w => w.completedAt >= startOfMonth);
    },

    getTotalVolume() {
      let total = 0;
      for (const w of (state.workoutHistory || [])) {
        for (const ex of w.exercises) {
          for (const s of ex.sets) {
            total += (s.weight || 0) * (s.reps || 0);
          }
        }
      }
      return total;
    },

    toggleFavorite(exerciseId) {
      this.update('favorites', favs => {
        const idx = favs.indexOf(exerciseId);
        if (idx >= 0) {
          favs.splice(idx, 1);
        } else {
          favs.push(exerciseId);
        }
        return favs;
      });
    },

    resetAll() {
      localStorage.removeItem(STORAGE_KEY);
      state = JSON.parse(JSON.stringify(defaultState));
      state.workoutHistory = generateSeedHistory();
      save();
      this.notify('*');
    },
  };
})();
