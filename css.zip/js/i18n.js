const I18n = (() => {
  let currentLang = 'en';

  function init() {
    // Try to get language from store settings, default to en
    const settings = Store.get('settings') || {};
    if (settings.language && TRANSLATIONS[settings.language]) {
      currentLang = settings.language;
    } else {
      // Auto-detect from browser
      const browserLang = navigator.language || navigator.userLanguage;
      if (browserLang && browserLang.toLowerCase().startsWith('tr')) {
        currentLang = 'tr';
      } else {
        currentLang = 'en';
      }
      
      // Save it to store
      Store.update('settings', s => {
        const next = s || {};
        next.language = currentLang;
        return next;
      });
    }
  }

  function setLanguage(lang) {
    if (TRANSLATIONS[lang]) {
      currentLang = lang;
      Store.update('settings', s => {
        const next = s || {};
        next.language = currentLang;
        return next;
      });
      // Re-render everything
      Navbar.render();
      Router.render(Router.getCurrentRoute());
    }
  }

  function getLanguage() {
    return currentLang;
  }

  function t(key, params = {}) {
    let str = TRANSLATIONS[currentLang][key] || TRANSLATIONS['en'][key] || key;
    
    // Simple templating {param}
    for (const [k, v] of Object.entries(params)) {
      str = str.replace(new RegExp(`{${k}}`, 'g'), v);
    }
    
    return str;
  }

  return { init, setLanguage, getLanguage, t };
})();
